



def film_price(tedad,mablagh,takhfif):
    price_tax = round((tedad * mablagh * 1.1)-((tedad * mablagh) * (takhfif/100)))
    print("you shoud pay:",price_tax,"t")
