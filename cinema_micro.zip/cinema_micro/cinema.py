

from function import *

films = ["film_1","film_2","film_3","film_4","film_5"]


while True:
    menu = input("1.buy a ticket 2.exit:")
    match menu:
        case "1":
            film_person_chose = input("""
film 1 : 200t
film 2 : 300t  (20% takhfif)
film 3 : 150t
film 4 : 250t  (10% takhfif)
film 5 : 100t 

enter your choice(just enter a number):""")
            while True:
                match film_person_chose:
                    case "1":
                        number = int(input("how many:"))
                        price = int(input("enter price:"))
                        takhfif = int(input("enter a takhfif(be darsad):"))
                        film_price(number,price,takhfif)
                        break
                    case "2":
                        number = int(input("how many:"))
                        price = int(input("enter price:"))
                        takhfif = int(input("enter a takhfif(be darsad):"))
                        film_price(number,price,takhfif)
                        break
                    case "3":
                        number = int(input("how many:"))
                        price = int(input("enter price:"))
                        takhfif = int(input("enter a takhfif(be darsad):"))
                        film_price(number,price,takhfif)
                        break
                    case "4":
                        number = int(input("how many:"))
                        price = int(input("enter price:"))
                        takhfif = int(input("enter a takhfif(be darsad):"))
                        film_price(number,price,takhfif)
                        break
                    case "5":
                        number = int(input("how many:"))
                        price = int(input("enter price:"))
                        takhfif = int(input("enter a takhfif(be darsad):"))
                        film_price(number,price,takhfif)
                        break
                    case _:
                        print("invailed")
                        break
        case "2":
            print("goodbye")
            break
        case _:
            print("invailed")