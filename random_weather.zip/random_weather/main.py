


import random



list_hava = ["sunny","rainy","abry"]
list_dama = []




while True:
    dama = random.randint(range(-30,60))
    hava = random.choice(list_hava)
    pishnahad = ""

    if dama < -10:
        pishnahad = "put cold dress"
    elif dama < 30:
        pishnahad = "put meduim dress"    
    else :
        pishnahad = "put hot dress"


    list_dama.append(dama)


    print(f"dama : {dama} hava : {hava}")
    print(pishnahad)
    print(list_dama)

    next_day = input("again(y/n):").strip().casefold()
    if next_day == "n":
        break
