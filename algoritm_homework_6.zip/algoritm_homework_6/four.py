




import random

chars = ["A","S","D","F","G","H","J","K","L","Q","W","E","R","T","Y","U","I","O","P","Z","X","C","V","B","N","M","a", "b", "c", "d", "e", "f", "g", "h", "i", "j","k", "l", "m", "n", "o", "p", "q", "r", "s", "t","u", "v", "w", "x", "y", "z","1","2","3","4","5","6","7","8","9","0","#","@"]

random_password = random.choices(chars,k=18)


print(random_password)