




import random


persons = ["ali","akbar","elias","mamad"]

rewards = ["cola","none","pizza","ps5"]

natige = []

for i in range(4):
   list_movaghat = []
   person_get_rewards = random.choice(persons)
   the_rewards = random.choice(rewards)
   list_movaghat.append(person_get_rewards)
   list_movaghat.append(the_rewards)
   natige.append(list_movaghat)
   persons.remove(person_get_rewards)
   rewards.remove(the_rewards)
print(natige)