





list_kol = []

while True:
    menu = input("1.sign up 2.sign in 3.exit:")
    if menu == "3":
        print("goodbye")
        break
    while True:
        match menu:
            case "1":
                list_movaghat = []
                fristname = input("enter your fristname:")
                lastname = input("enter your lastname:")
                username = input("enter your username:")
                password = input("enter your password:")
                python_score = float(input("enter python score:"))
                java_score = float(input("enter java score:"))
                html_score = float(input("enter html score:"))
                java_script_score = float(input("enter java script score:")) 
                list_movaghat.append(fristname)
                list_movaghat.append(lastname)
                list_movaghat.append(username)
                list_movaghat.append(password)
                list_movaghat.append("python score:")
                list_movaghat.append(python_score)
                list_movaghat.append("java score:")
                list_movaghat.append(java_score)
                list_movaghat.append("html score:")
                list_movaghat.append(html_score)
                list_movaghat.append("java script score:")
                list_movaghat.append(java_script_score)
                list_kol.append(list_movaghat)
                print(list_kol)
                break
            case "2":
                username_input = input("enter a username:")
                for i in list_kol:
                    for j in i:
                        if j == username_input:
                            list_hadaf = list_kol.index(i)
                            corect_password = list_kol[list_hadaf][3]
                            while True:
                                password_input = input("enter your password:")
                                if password_input == corect_password:
                                    print(i)
                                    break
                                else:
                                    print("wrong password")
                            break
                    break
                else:
                    print("this username doesn't exits")
                break
            case _:
                print("invailed")
                break