




list_kol = []

list_nomre_python = []

list_nomre_java = []

list_nomre_html = []


while True:
    menu = input("""
enter a anything for sabt score
enter a '8888' to exit
your choice:""")
    if menu == "8888":
        print(list_kol)
        avrage_python_scores = sum(list_nomre_python) / len(list_nomre_python)
        avrage_java_scores = sum(list_nomre_java) / len(list_nomre_java)
        avrage_html_scores = sum(list_nomre_html) / len(list_nomre_html)
        print("avrage python scores:",avrage_python_scores)
        print("avrage java scores:",avrage_java_scores)
        print("avrage html scores:",avrage_html_scores)
        break
    else:
        list_movaghat = []
        fristname = input("enter a fristname:")
        lastname = input("enter a lastname:")
        python_score = float(input("enter a python score:"))
        java_score = float(input("enter a java score:"))
        html_score = float(input("enter a html score:"))
        list_movaghat.append(fristname)
        list_movaghat.append(lastname)
        list_movaghat.append(python_score)
        list_movaghat.append(java_score)
        list_movaghat.append(html_score)
        list_kol.append(list_movaghat)
        list_nomre_python.append(python_score)
        list_nomre_java.append(java_score)
        list_nomre_html.append(html_score)










