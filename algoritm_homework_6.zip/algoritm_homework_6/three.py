

import random

persons = ["ali","akbar","elias","mamad"]

winner = random.choices(persons,weights=[1,1,4,1])[0]

print(winner)