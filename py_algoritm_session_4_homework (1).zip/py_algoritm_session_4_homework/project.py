








# sign up form
#   frist name --> frist leather upper /
#   last name --> frist leather upper /
#   phone number --> chek is num /
#   home adress /
#   posti code /
#   username /
#   password /
#   save password & username /
# menu
#   sign up /
#   sign in /
#   exit /


password = ""
username = ""
frist_name = ""
last_name = ""
phone_number = ""
home_adress = ""
posti_code = ""


while True:
    person_choice_in_menu = input("""

enter "1" to sign up
enter "2" to sign in
enter "3" to exit

enter your choice:""")
    if person_choice_in_menu == "3":
        print("goodbye")
        break
    while True:
        match person_choice_in_menu:
            case "1":
                frist_name_person_input = input("enter your frist name:").title()
                frist_name = frist_name_person_input
                last_name_person_input = input("enter your last namr:").title()
                last_name = last_name_person_input
                phone_number_person_input = int(input("enter your phone number:"))
                phone_number = phone_number_person_input
                home_adress_person_input = input("enter your home adress:")
                home_adress = home_adress_person_input
                posti_code_person_input = input("enter your posti code:")
                posti_code = posti_code_person_input
                password_person_input = input("enter your password:")
                password = password_person_input
                username_person_input = input("enter your username:")
                username = username_person_input
                break
            case "2":
                username_person_input = input("enter your username:")
                password_person_input = input("enter your password:")
                if password_person_input != "" and username_person_input != "" and username_person_input == username and password_person_input == password:
                    print("login")
                    break
                else:
                    print("wrong password or username")
                    continue
            case _:
                print("your choice is inviled")
                break