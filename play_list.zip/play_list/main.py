

from function import *

play_list = [].sort()



while True:
    menu_play_list = input("""
1. see play list
2. search in play list
3. add song
4. remove song
5. exit
enter thing you want:""")
    match menu_play_list:
        case "1":
            make_beautiful_play_list(play_list)
        case "2":
            while True:
                type_of_search = input("1.search with name 2.search with num:")
                match type_of_search:
                    case "1":
                        song_person_searched = input("enter the song you want:").strip().lower()
                        search_with_name_of_song_in_play_list(play_list,song_person_searched)
                        break
                    case "2":
                        num_person_searched = int(input("enter the num you want:"))
                        search_with_num_of_song_in_play_list(play_list,num_person_searched)
                        break
                    case _:
                        print("invalid")
        case "3":
            song_person_want_to_add = input("enter the song you want add:").strip()
            play_list.append(song_person_want_to_add)
        case "4":
            while True:
                the_type_of_remove = input("1.remove with name 2.remove with num:")
                match the_type_of_remove:
                    case "1":
                        the_song_person_want_to_remove = input("enter the song you want remove:").strip()
                        play_list = remove_song_with_name_of_song(play_list,the_song_person_want_to_remove)
                        break
                    case "2":
                        the_num_person_want_to_remove = int(input("enter the num you want remove:").strip())
                        play_list = remove_song_with_num_of_song(play_list,the_num_person_want_to_remove)
                        break
                    case _:
                        print("invalid")
        case "5":
            print("goodbye")
            break
        case _:
            print("invalid")