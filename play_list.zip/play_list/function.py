


song_num = 1
def make_beautiful_play_list(play_list:list) -> None:
    if play_list == []:
        print("your play list is empty")
    else:
        print("play list:")
        print()
        for i in play_list:
            print(f"{song_num}. {i}")
            song_num += 1


def search_with_name_of_song_in_play_list(play_list:list,song:str) -> None:
    if song in play_list:
        index_of_song_in_list = (play_list.index(song)) + 1
        print(f"{song} is {index_of_song_in_list} song in your play list")
    else:
        print("this song doesn't exit")


def search_with_num_of_song_in_play_list(play_list:list,num:int) -> None:
    if len(play_list) < num or num > 0:
        print("this num doesn't exit")
    else:
        num_index = num - 1
        song_person_want = play_list[num_index]
        print(f"the song you want is {song_person_want}")



def remove_song_with_name_of_song(play_list:list,song:str) -> None:
    if song in play_list:
        new_play_list = play_list.remove(song)
        print("song is removed")
    else:
        print("this song doesn't exit")
        new_play_list = play_list

    return new_play_list
    


def remove_song_with_num_of_song(play_list:list,num:int) -> None:
    if len(play_list) < num or num > 0:
        print("this num doesn't exit")
        new_play_list = play_list
    else:
        num_index = num - 1
        new_play_list = play_list.pop(play_list[num_index])
        print("song is removed")

    return new_play_list
       