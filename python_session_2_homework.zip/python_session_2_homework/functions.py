








def check_info(frist_name:str,last_name:str,age:int,gender:str,edu:str,email:str,phone_number:str,username:str,password:str) -> bool:
    """checing person informtion

    Args:
        frist_name (str): frist name of person
        last_name (str): last name of person
        age (int): age of person
        gender (str): gender of person
        edu (str): edu of person
        email (str): email of person
        phone_number (str): phone number of person
        username (str): username of person
        password (str): password of person

    Returns:
        bool: informtion is okay or not okay
    """
    person_info_valid = True

    if frist_name.replace(" ","").isalpha() == False:
        person_info_valid = False
    elif last_name.replace(" ","").isalpha() == False:
        person_info_valid = False
    elif age < 18 :
        person_info_valid = False
    elif gender != "1" and gender != "2" and gender != "3":
        person_info_valid = False
    elif edu != "1" and edu != "2" and edu != "3" and edu != "4" :
        person_info_valid = False
    elif email.endswith("@gmail.com") == False:
        person_info_valid = False
    elif phone_number.isdigit() == False:
        person_info_valid = False
    elif username.isalnum() == False:
        person_info_valid = False
    elif password.isalnum() == False:
        person_info_valid = False



    return person_info_valid



list_movaghat = []


def make_list_person_info(frist_name:str,last_name:str,age:int,gender:str,edu:str,email:str,phone_number:str,username:str,password:str) -> list:
    """make person info list
    
        Args:
            frist_name (str): frist name of person
            last_name (str): last name of person
            age (int): age of person
            gender (str): gender of person
            edu (str): edu of person
            email (str): email of person
            phone_number (str): phone number of person
            username (str): username of person
            password (str): password of person
    
        Returns:
            list: list of person info
        """

    
    match gender:
        case "1":
            gender = "male"
        case "2":
            gender = "female"
        case "3":
            gender = "other"


    match edu:
        case "1":
            edu = "diploma"
        case "2":
            edu = "lisans"
        case "3":
            edu = "arshad"
        case "4":
            edu = "phd"


    list_movaghat.append(frist_name)
    list_movaghat.append(last_name)
    list_movaghat.append(age)
    list_movaghat.append(gender)
    list_movaghat.append(edu)
    list_movaghat.append(email)
    list_movaghat.append(phone_number)
    list_movaghat.append(username)
    list_movaghat.append(password)

    return list_movaghat

def cheking_login(password:str,username:str,all_persons:list) -> str:
    """checkin the login

    Args:
        password (str): password of person
        username (str): username of person
        all_persons (list): list of all person

    Returns:
        str: login is okay or not okay
    """

    

    for i in all_persons:
        if i[-1] == password and i[-2] == username:
            print("login")
            taiid_login = True
            break
    else:
        print("doesnt login")
        
