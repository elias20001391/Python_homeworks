




from functions import *


persons_info = []


while True:
    menu = input("1.sign in  2.sign up  3.exit:")
    match menu:
        case "1":
            password_person_input = input("enter your password:").strip()
            username_person_input = input("enter your username:").strip()
            cheking_login(password=password_person_input,username=username_person_input,all_persons=persons_info)
                        
        case "2":
            frist_name = input("enter your frist name:").strip()
            last_name = input("enter your last name:").strip()
            age = int(input("enter your age:").strip())
            gender = input("1.male 2.female 3.other:").strip()
            edu = input("1.diploma 2.lisans 3.arshad 4.phd:").strip()
            email = input("enter your email:").strip()
            phone_number = input("enter your phone number:").strip()
            username = input("enter your username:").strip()
            password = input("enter your password:").strip()

            checking_info = check_info(frist_name=frist_name,last_name=last_name,age=age,gender=gender,edu=edu,email=email,phone_number=phone_number,username=username,password=password)

            if checking_info == True:
                persons_info.append(make_list_person_info(frist_name=frist_name,last_name=last_name,age=age,gender=gender,edu=edu,email=email,phone_number=phone_number,username=username,password=password))
            else:
                print("some mistake try again")
            print(make_list_person_info(frist_name=frist_name,last_name=last_name,age=age,gender=gender,edu=edu,email=email,phone_number=phone_number,username=username,password=password))
            print(persons_info)
        case "3":
            print("goodbye")
            break
        case _:
            print("invalid")